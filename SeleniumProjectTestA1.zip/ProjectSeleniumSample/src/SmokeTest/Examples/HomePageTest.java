package SmokeTest.Examples;

import org.junit.Assert;
import org.junit.Test;

public class HomePageTest extends GeneralTests {

    @Test
    public void testPage() throws InterruptedException {
        Thread.sleep(4000);
        Assert.assertTrue("Page title is incorrect", driver.getTitle().contains("Avanade"));

    }
}
