package SmokeTest.Examples;

import org.openqa.selenium.WebDriver;

public class HomePageLocatorsMethods {
    WebDriver driver;

    public HomePageLocatorsMethods(WebDriver driver){
        this.driver = driver;
    }

}
