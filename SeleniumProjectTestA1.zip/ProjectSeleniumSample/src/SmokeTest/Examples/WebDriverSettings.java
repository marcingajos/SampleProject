package SmokeTest.Examples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverSettings {
    private static final String URL = "https://www.avanade.com/en-us";
    WebDriver driver = null;


    protected void setDriverProperties() {
        System.setProperty("webdriver.chrome.driver", "src/chromedriver96.exe");
    }

    protected WebDriver startDriver() {
        setDriverProperties();
        return driver = new ChromeDriver();
    }

    protected void navigateToBasicURL(WebDriver driver) {

        driver.get(URL);
        System.out.println("Navigate to page");
    }

}
