package SmokeTest.Examples;

import org.openqa.selenium.WebDriver;

public class Init {
    protected static WebDriver driver;
    protected static HomePageLocatorsMethods homePageLocatorsMethods;

    public static void initPages() {
        homePageLocatorsMethods = new HomePageLocatorsMethods(driver);
    }


    public static void runInit() {
        WebDriverSettings myWebDriverSettings = new WebDriverSettings();
        driver = myWebDriverSettings.startDriver();
        myWebDriverSettings.navigateToBasicURL(driver);
        driver.manage().window().maximize();
    }

    public void finalizeEverything() {
        driver.close();
        System.out.println("Driver close");
        driver.quit();
        System.out.println("Driver quite");
    }
}
