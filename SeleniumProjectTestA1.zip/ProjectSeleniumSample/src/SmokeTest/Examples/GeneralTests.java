package SmokeTest.Examples;

import org.junit.After;
import org.junit.Before;

public class GeneralTests extends Init{

    @Before
    public void setUP() {
        runInit();
        initPages();
    }

    @After
    public void ClearAll() {
        finalizeEverything();
    }
}
